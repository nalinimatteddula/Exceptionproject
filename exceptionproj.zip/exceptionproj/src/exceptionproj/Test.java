package exceptionproj;

public class Test {

	public static void main(String[] args) {
		try {
		SavingsAccount account = new SavingsAccount(101,5000,1234);
		account = null;
		account.withdrawAmount(2000);
		System.out.println("withdrawl done");
		}catch (Exception e) {
			
			System.out.println("catch block");
		}
		System.out.println("End of main()");
	}

}
